import React, { Component } from 'react';

class FundBox extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return;
	}
}

export default FundBox;

import React, { Component } from 'react';

class IdeaView extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return;
	}
}

export default IdeaView;

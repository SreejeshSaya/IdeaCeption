import React, { Component } from 'react';

class IdeaList extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		// return; return list of latest IdeaCards
	}
}

export default IdeaList;

//map for now
//local storage

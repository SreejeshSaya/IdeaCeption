import React, { Component } from 'react';

class UserGreeting extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return; //Sign in or Sign out Option
	}
}

export default UserGreeting;

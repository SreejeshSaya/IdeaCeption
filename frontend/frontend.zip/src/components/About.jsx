import React, { Component } from 'react';

class About extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return;
		// Insert about website and contact information
	}
}

export default About;
